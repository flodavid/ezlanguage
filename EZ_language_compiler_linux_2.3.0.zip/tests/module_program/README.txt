Le module person est utilisé dans programme "program.ez"
