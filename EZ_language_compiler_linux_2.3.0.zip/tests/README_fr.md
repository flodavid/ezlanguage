Tests
=====

Quelques fichiers permettant de faire des tests (notamment des fichiers en ez).

Ces fichiers sont temporaires, ils peuvent donc être modifiés à tout moment.

# Tests

main_simple_procedure: (procedure) : test sur une procédure vide
main_simple_affichage: (affichage) : test sur l'affichage

https://docs.google.com/document/d/1Ij-LUV5D7xJDgw1R9tnCZKfIgMQzEHf8VbJu6yi5OFg/edit?usp=sharing
