Tests
=====

Some files that let you test the compiler (ez langage files for example).

Those files can be moved and modify at any time, so be careful.

--------

main_simple_procedure: (procedure) : test on empty procedure
main_simple_affichage: (affichage) : test on display

https://docs.google.com/document/d/1Ij-LUV5D7xJDgw1R9tnCZKfIgMQzEHf8VbJu6yi5OFg/edit?usp=sharing
